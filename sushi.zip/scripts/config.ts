const config = {
  bsc: {
  },
  mainnet: {
  },
};

export default config;
